// js/workers/pricingWorker.js
self.onmessage = async (e)=>{
  const { cart, promo, shippingMethod, taxRate } = e.data;
  const items = cart.items || {}; const catalog = cart.catalog || {};
  const subtotal = Object.entries(items).reduce((s,[id,qty]) => s + (catalog[id]?.price||0)*qty, 0);
  // fetch promotions
  let promotions = await fetch('assets/data/promotions.json').then(r=>r.json());
  if (promo) promotions = promotions.filter(p => p.code === promo);
  // evaluate discounts
  let discounts = 0;
  for (const p of promotions){
    if (p.type === 'percent' && subtotal >= (p.conditions?.minSubtotal||0)){
      discounts += subtotal * (p.value/100);
    } else if (p.type === 'bogo'){
      const { productId, buy, get } = p.value; const qty = items[productId] || 0;
      if (qty >= buy+get){ discounts += Math.floor(qty/(buy+get)) * (catalog[productId]?.price||0) * get; }
    } else if (p.type === 'percent' && p.conditions?.hours){
      const h = new Date().getHours(); if (p.conditions.hours.includes(h)) discounts += subtotal * (p.value/100);
    }
  }
  // shipping
  let shipping = 0; if (shippingMethod === 'standard') shipping = subtotal > 25 ? 0 : 4.99; if (shippingMethod === 'express') shipping = 12.99;
  // FREESHIP promo
  if (promotions.some(p => p.type==='shipping')) shipping = 0;
  const taxable = Math.max(0, subtotal - discounts) + shipping;
  const tax = +(taxable * (taxRate||0)).toFixed(2);
  const total = +(taxable + tax).toFixed(2);
  self.postMessage({ subtotal:+subtotal.toFixed(2), discounts:+discounts.toFixed(2), shipping:+shipping.toFixed(2), tax, total });
};
