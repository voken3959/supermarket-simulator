// js/utils/pricing.js
export async function calculateTotals(cart, { promo, shippingMethod='standard', taxRate=0.07 } = {}){
  return await new Promise((resolve) => {
    const worker = new Worker('js/workers/pricingWorker.js');
    worker.onmessage = (e)=> resolve(e.data);
    worker.postMessage({ cart, promo, shippingMethod, taxRate });
  });
}
