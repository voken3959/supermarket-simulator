// js/utils/format.js
export const money = (n) => Intl.NumberFormat(undefined,{style:'currency',currency:'USD'}).format(n);
export const clamp = (v,min,max)=> Math.max(min, Math.min(max, v));
