// js/components/overlayNavbar.js
import { getCartCount } from '../modules/cart.js';

export function mountOverlayNavbar(el){
  el.innerHTML = `
    <div class="row">
      <strong>🏬 StoreSim 2D</strong>
      <span class="small">Walk with arrows / WASD. Interact: E. Checkout: Space at register.</span>
    </div>
    <div class="row">
      <button id="btn-show-catalog" class="btn">Catalog</button>
      <button id="btn-show-cart" class="btn">Cart <span class="badge" id="cart-count">0</span></button>
      <button id="btn-show-checkout" class="btn primary">Checkout</button>
      <button id="btn-show-report" class="btn">Daily Report</button>
    </div>
  `;

  const cartBadge = el.querySelector('#cart-count');
  function updateCount(){ cartBadge.textContent = getCartCount(); }
  setInterval(updateCount, 500);
  updateCount();

  document.getElementById('btn-show-catalog').onclick = ()=> document.getElementById('catalog-panel').scrollIntoView({behavior:'smooth'});
  document.getElementById('btn-show-cart').onclick = ()=> document.getElementById('cart-panel').scrollIntoView({behavior:'smooth'});
  document.getElementById('btn-show-checkout').onclick = ()=> document.getElementById('checkout-panel').scrollIntoView({behavior:'smooth'});
  document.getElementById('btn-show-report').onclick = ()=> document.getElementById('report-panel').scrollIntoView({behavior:'smooth'});
}
