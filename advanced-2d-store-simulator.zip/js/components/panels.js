// js/components/panels.js
import { money } from '../utils/format.js';
import { addToCart, getCart, removeFromCart, setQty, clearCart } from '../modules/cart.js';
import { calculateTotals } from '../utils/pricing.js';
import { simulatePayment } from '../modules/payments.js';
import { updateStock } from '../modules/inventory.js';

export function mountPanels({ catalogEl, cartEl, checkoutEl, reportEl }){
  renderCatalog(catalogEl);
  renderCart(cartEl);
  renderCheckout(checkoutEl);
  renderReport(reportEl);

  async function renderCatalog(el){
    const products = await (await fetch('assets/data/products.json')).json();
    el.innerHTML = '<h2>Catalog</h2><div class="grid" id="grid"></div>';
    const grid = el.querySelector('#grid');
    products.forEach(p => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <img src="${p.image}" alt="${p.name}" style="width:100%; height:140px; object-fit:cover; border-radius:8px" />
        <h3>${p.name}</h3>
        <div class="row"><span>${money(p.price)}</span><span class="badge">★ ${p.rating}</span></div>
        <div class="row"><small class="small">Stock: ${p.stock}</small><span class="right"></span></div>
        <button class="btn primary">Add</button>
      `;
      card.querySelector('button').onclick = ()=> addToCart(p.id, 1);
      grid.appendChild(card);
    });
  }

  async function renderCart(el){
    const cart = getCart();
    const items = Object.entries(cart.items);
    el.innerHTML = '<h2>Cart</h2>';
    const list = document.createElement('div'); list.className = 'cart-items';
    items.forEach(([id, qty])=>{
      const p = cart.catalog[id];
      const row = document.createElement('div');
      row.className = 'row';
      row.innerHTML = `<span>${p.name} × <input type="number" min="1" value="${qty}" style="width:72px"></span>
                       <span>${money(p.price*qty)} <button data-id="${id}">🗑</button></span>`;
      row.querySelector('input').onchange = (e)=> setQty(id, +e.target.value);
      row.querySelector('button').onclick = ()=> { removeFromCart(id); renderCart(el); };
      list.appendChild(row);
    });
    el.appendChild(list);
    const totals = await calculateTotals(getCart());
    const summary = document.createElement('div');
    summary.innerHTML = `<hr/><strong>Total: ${money(totals.total)}</strong>`;
    el.appendChild(summary);
  }

  async function renderCheckout(el){
    const totals = await calculateTotals(getCart());
    el.innerHTML = `
      <h2>Checkout</h2>
      <div class="grid">
        <div class="card"><label>Email <input id="email" placeholder="you@example.com"/></label></div>
        <div class="card">
          <label>Promo code <input id="promo" placeholder="WELCOME10"/></label>
          <button id="apply" class="btn">Apply</button>
        </div>
        <div class="card">
          <button id="pay" class="btn primary">Pay ${money(totals.total)}</button>
          <div id="status" class="small"></div>
        </div>
      </div>`;

    el.querySelector('#apply').onclick = async ()=> {
      const code = el.querySelector('#promo').value.trim();
      const totals = await calculateTotals(getCart(), { promo: code });
      el.querySelector('#pay').textContent = `Pay ${money(totals.total)}`;
    };

    el.querySelector('#pay').onclick = async ()=> {
      const totals = await calculateTotals(getCart(), { promo: el.querySelector('#promo').value.trim()||null });
      el.querySelector('#status').textContent = 'Processing...';
      try {
        const res = await simulatePayment({ amount: totals.total });
        updateStock(getCart().catalog, getCart().items);
        clearCart();
        el.querySelector('#status').innerHTML = 'Payment complete ✅';
        renderCart(document.getElementById('cart-panel'));
        renderReport(document.getElementById('report-panel'));
      } catch(e){
        el.querySelector('#status').textContent = 'Payment failed: ' + e.message;
      }
    };
  }

  function renderReport(el){
    const analytics = JSON.parse(localStorage.getItem('analytics')||'[]');
    const orders = JSON.parse(localStorage.getItem('orders')||'[]');
    const revenue = orders.reduce((s,o)=> s + (o.total||0), 0);
    el.innerHTML = `<h2>Daily Report</h2>
      <div class="grid">
        <div class="card"><h3>Orders</h3><strong>${orders.length}</strong></div>
        <div class="card"><h3>Revenue</h3><strong>$${revenue.toFixed(2)}</strong></div>
        <div class="card"><h3>Events</h3><strong>${analytics.length}</strong></div>
      </div>`;
  }

  // expose re-renderers (simple)
  window._uiRefresh = () => {
    renderCart(document.getElementById('cart-panel'));
    renderCheckout(document.getElementById('checkout-panel'));
  };
}
