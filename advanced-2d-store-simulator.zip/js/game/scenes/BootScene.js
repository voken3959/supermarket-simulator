// js/game/scenes/BootScene.js
export class BootScene extends Phaser.Scene {
  constructor(){ super('Boot'); }
  preload(){
    // minimal placeholder assets
    this.load.image('player', 'assets/img/tiles.png');
    this.load.image('customer', 'assets/img/tiles.png');
    this.load.image('shelf', 'assets/img/tiles.png');
    this.load.image('register', 'assets/img/tiles.png');
  }
  create(){ this.scene.start('Store'); }
}
