// js/game/scenes/StoreScene.js
import { spawnCustomerWave } from '../systems/ai.js';

export class StoreScene extends Phaser.Scene {
  constructor(){ super('Store'); }

  create(){
    // simple store layout
    const w = this.scale.width, h = this.scale.height;
    this.add.rectangle(w/2, h/2, w, h, 0xe7f0f7).setDepth(0);
    this.player = this.physics.add.image(120, h-80, 'player').setScale(0.5);
    this.player.setCollideWorldBounds(true);

    // interactive zones
    this.register = this.add.rectangle(w-120, h-80, 80, 60, 0x333333).setDepth(1);
    this.shelves = [
      this.add.rectangle(400, 160, 180, 40, 0xaaaaaa),
      this.add.rectangle(800, 160, 180, 40, 0xaaaaaa),
      this.add.rectangle(400, 320, 180, 40, 0xaaaaaa),
      this.add.rectangle(800, 320, 180, 40, 0xaaaaaa),
    ];

    this.physics.world.enable(this.register);
    this.shelves.forEach(s => this.physics.world.enable(s));

    // keys
    this.cursors = this.input.keyboard.createCursorKeys();
    this.wasd = this.input.keyboard.addKeys('W,A,S,D');
    this.keyE = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.E);
    this.keySpace = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);

    // customer group
    this.customers = this.add.group();

    // spawn initial wave
    spawnCustomerWave(this, 4);

    // collisions (none heavy here)

    // show UI scene
    this.scene.launch('UI');
  }

  update(){
    const speed = 200;
    const vx = (this.cursors.left.isDown || this.wasd.A.isDown ? -1 : this.cursors.right.isDown || this.wasd.D.isDown ? 1 : 0) * speed;
    const vy = (this.cursors.up.isDown || this.wasd.W.isDown ? -1 : this.cursors.down.isDown || this.wasd.S.isDown ? 1 : 0) * speed;
    this.player.setVelocity(vx, vy);

    // interaction: pick items at shelves
    if (Phaser.Input.Keyboard.JustDown(this.keyE)){
      const nearShelf = this.shelves.find(s => Phaser.Math.Distance.Between(this.player.x, this.player.y, s.x, s.y) < 120);
      if (nearShelf) window.dispatchEvent(new CustomEvent('game:interact:shelf'));
    }

    // interaction: checkout at register
    if (Phaser.Input.Keyboard.JustDown(this.keySpace)){
      const nearReg = Phaser.Math.Distance.Between(this.player.x, this.player.y, this.register.x, this.register.y) < 140;
      if (nearReg) window.dispatchEvent(new CustomEvent('game:interact:register'));
    }
  }
}
