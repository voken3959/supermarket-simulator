// js/game/scenes/UIScene.js
export class UIScene extends Phaser.Scene {
  constructor(){ super('UI'); }
  create(){
    const tip = this.add.text(12, 8, 'E: pick items at shelves  |  Space: checkout at register', { fontSize: '14px', color:'#000' });
    tip.setScrollFactor(0).setDepth(100);
  }
}
