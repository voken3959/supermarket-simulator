// js/game/bridge.js
import { addToCart, getCart } from '../modules/cart.js';
import { calculateTotals } from '../utils/pricing.js';

window.addEventListener('game:interact:shelf', async ()=>{
  // simulate picking a random product
  const ids = Object.keys(getCart().catalog);
  if (!ids.length){
    await fetch('assets/data/products.json').then(r=>r.json()).then(arr => arr.forEach(p => getCart().catalog[p.id]=p));
  }
  const all = Object.keys(getCart().catalog);
  const id = all[Math.floor(Math.random()*all.length)];
  addToCart(id, 1);
  window._uiRefresh && window._uiRefresh();
});

window.addEventListener('game:interact:register', async ()=>{
  // compute totals and scroll to checkout
  const totals = await calculateTotals(getCart());
  document.getElementById('checkout-panel').scrollIntoView({ behavior:'smooth' });
});
