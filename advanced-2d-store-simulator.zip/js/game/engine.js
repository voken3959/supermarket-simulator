// js/game/engine.js
import { BootScene } from './scenes/BootScene.js';
import { StoreScene } from './scenes/StoreScene.js';
import { UIScene } from './scenes/UIScene.js';

export function initGame({ parent='game-root' } = {}){
  const config = {
    type: Phaser.AUTO,
    parent,
    width: 1200,
    height: 520,
    backgroundColor: '#95c2de',
    physics: { default: 'arcade', arcade: { gravity: { y: 0 }, debug: false } },
    scene: [BootScene, StoreScene, UIScene],
    pixelArt: false,
  };
  new Phaser.Game(config);
}
