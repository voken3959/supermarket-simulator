// js/game/systems/ai.js
export function spawnCustomerWave(scene, n=3){
  for (let i=0;i<n;i++){
    const c = scene.add.circle(60 + Math.random()*80, 60+Math.random()*60, 10, 0x222244);
    scene.tweens.add({ targets: c, x: 200 + Math.random()*700, yoyo: false, duration: 2500 + Math.random()*1500, onComplete: ()=> {
      // after 'shopping', walk to register then vanish
      scene.tweens.add({ targets: c, x: scene.register.x, y: scene.register.y, duration: 2200, onComplete: ()=> c.destroy() });
    }});
  }
  // periodically spawn more
  scene.time.addEvent({ delay: 8000, callback: ()=> spawnCustomerWave(scene, 2+Math.floor(Math.random()*3)) });
}
