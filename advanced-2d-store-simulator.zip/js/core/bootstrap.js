// js/core/bootstrap.js
import { mountOverlayNavbar } from '../components/overlayNavbar.js';
import { mountPanels } from '../components/panels.js';
import { initGame } from '../game/engine.js';
import { i18n } from '../modules/i18n.js';
import { storage } from './storage.js';

i18n.setLocale(storage.get('locale') || 'en');

mountOverlayNavbar(document.getElementById('overlay-navbar'));
mountPanels({
  catalogEl: document.getElementById('catalog-panel'),
  cartEl: document.getElementById('cart-panel'),
  checkoutEl: document.getElementById('checkout-panel'),
  reportEl: document.getElementById('report-panel'),
});

initGame({ parent: 'game-root' });

console.log('%cAdvanced 2D Store Simulator loaded', 'color:green');

import '../game/bridge.js';
