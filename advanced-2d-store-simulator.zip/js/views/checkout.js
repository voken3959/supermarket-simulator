// placeholder view (unused in this build)
export function renderCheckout(){}