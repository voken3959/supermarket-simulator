// js/modules/cart.js
import { storage } from '../core/storage.js';

const state = storage.get('cart') || { items: {}, catalog: {} };

async function ensureCatalog(){
  if (Object.keys(state.catalog).length) return state.catalog;
  const base = await fetch('assets/data/products.json').then(r=>r.json());
  base.forEach(p => state.catalog[p.id] = p);
  const override = JSON.parse(localStorage.getItem('catalog_override')||'null');
  if (override) { state.catalog = Object.fromEntries(override.map(p=>[p.id,p])); }
  storage.set('cart', state);
  return state.catalog;
}

export async function loadCatalog(){ return await ensureCatalog(); }
export function getCart(){ return state; }
export function getCartCount(){ return Object.values(state.items).reduce((a,b)=>a+b,0); }
export function clearCart(){ state.items = {}; storage.set('cart', state); }
export function addToCart(productId, qty=1){ state.items[productId] = (state.items[productId]||0) + qty; storage.set('cart', state); }
export function setQty(productId, qty){ if (qty<=0) delete state.items[productId]; else state.items[productId]=qty; storage.set('cart', state); }
export function removeFromCart(productId){ delete state.items[productId]; storage.set('cart', state); }
