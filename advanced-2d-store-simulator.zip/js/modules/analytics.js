// js/modules/analytics.js
export class Analytics {
  track(event, data){ const all = JSON.parse(localStorage.getItem('analytics')||'[]'); all.push({ ts: Date.now(), event, data }); localStorage.setItem('analytics', JSON.stringify(all)); }
  events(){ return JSON.parse(localStorage.getItem('analytics')||'[]'); }
  clear(){ localStorage.removeItem('analytics'); }
}
export const analytics = new Analytics();
