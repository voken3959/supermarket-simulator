// js/modules/i18n.js
class I18N {
  dict = { en: { add: 'Add' } };
  locale = 'en';
  t(k){ return (this.dict[this.locale] && this.dict[this.locale][k]) || k; }
  setLocale(loc){ this.locale = loc; }
}
export const i18n = new I18N();
