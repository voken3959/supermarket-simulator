// js/modules/payments.js
export async function simulatePayment({ amount, method='card' }){
  await new Promise(r=> setTimeout(r, 500));
  if (Math.random() < 0.05) throw new Error('Card declined');
  const order = { id: 'ord_'+Math.random().toString(36).slice(2), total: amount, at: Date.now() };
  const all = JSON.parse(localStorage.getItem('orders')||'[]'); all.push(order); localStorage.setItem('orders', JSON.stringify(all));
  return { status:'succeeded', order };
}
