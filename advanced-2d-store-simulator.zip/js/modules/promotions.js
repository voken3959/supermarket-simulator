// js/modules/promotions.js
export function applyPromotions(cart, promotions){
  let discounts = 0; const subtotal = Object.entries(cart.items).reduce((s,[id,qty])=> s + (cart.catalog[id]?.price||0)*qty, 0);
  for (const promo of promotions){
    if (promo.type === 'percent' && subtotal >= (promo.conditions?.minSubtotal||0)) discounts += subtotal * (promo.value/100);
    if (promo.type === 'shipping' && subtotal >= (promo.conditions?.minSubtotal||0)) { /* handled in worker */ }
    if (promo.type === 'bogo'){ const { productId, buy, get } = promo.value; const qty = cart.items[productId]||0; if (qty >= buy+get){ discounts += Math.floor(qty/(buy+get)) * (cart.catalog[productId]?.price||0) * get; } }
    if (promo.type === 'percent' && promo.conditions?.hours){ const h = new Date().getHours(); if (promo.conditions.hours.includes(h)) discounts += subtotal * (promo.value/100); }
  }
  return +discounts.toFixed(2);
}
