// js/modules/inventory.js
export function updateStock(catalog, items){
  for (const [id, qty] of Object.entries(items)){
    const p = catalog[id]; if (!p) continue; p.stock = Math.max(0, p.stock - qty);
  }
  localStorage.setItem('catalog_override', JSON.stringify(Object.values(catalog)));
  return catalog;
}
