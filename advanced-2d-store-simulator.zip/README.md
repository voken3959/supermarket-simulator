# Advanced 2D Store Simulator (Phaser + Normal UI)

A hybrid **store tycoon**: move in a 2D shop (Phaser.js) but interact with a **normal e-commerce UI overlay** (catalog, cart, checkout, reports). Host it on **GitHub Pages**.

## Highlights
- 2D store world (Phaser 3) with shelves, register, player movement, simple AI customers.
- Normal UI overlay: Catalog, Cart, Checkout, Daily Report.
- Promotions, shipping, tax via **Web Worker** pricing engine.
- Modular architecture with many scripts (game, UI, systems, modules, workers).
- LocalStorage persistence for orders, analytics, and catalog overrides.

## Controls
- Move: Arrow keys / WASD
- Interact shelves: **E** (adds random item to cart)
- Checkout at register: **Space** (scrolls to checkout panel)

## Run
- Open `index.html` using a local server (or push to GitHub Pages).
- Phaser is loaded from CDN.

## Structure
- `js/game/` – Phaser engine, scenes, AI system, bridge to UI
- `js/components/` – overlay panels (catalog, cart, checkout, report)
- `js/modules/` – cart, promotions, payments, inventory, analytics, i18n
- `js/workers/` – pricingWorker.js (promos, shipping, tax)
- `assets/data/` – sample products & promotions
